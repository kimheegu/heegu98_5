package com.igproject.icu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.igproject.icu.vo.IcuVO;

@Mapper
@Repository("studentDAO")
public interface StudentDAO {
	//학생 로그인
		public IcuVO loginByStd(IcuVO icuVO) throws DataAccessException;
		// 학생 메인페이지 정보
		public List<IcuVO> selectStd_Info(String std_id) throws DataAccessException;
		// 학생 개인정보 확인
		public List<IcuVO> selectStd_Detail(String std_id) throws DataAccessException;
		// 학생 개인정보 수정
		public int updateStd_Info(IcuVO icuVO) throws DataAccessException;
		// 학기 성적 조회
		public List<IcuVO> selectStd_Sem(IcuVO icuVO) throws DataAccessException;
		// 전체 학기 성적 조회
		public List<IcuVO> selectStd_All(String std_id) throws DataAccessException;
		// 이수 학점 가져오기
		public List<IcuVO> selectStd_Credit(String std_id) throws DataAccessException;
		// 수강 과목 조회
		public List<IcuVO> selectStd_Lec(String std_id) throws DataAccessException;
		// 출결 현황 조회
		// 출석
		public List<IcuVO> selectStd_Attd_T(String std_id) throws DataAccessException;
		// 결석
		public List<IcuVO> selectStd_Attd_F(String std_id) throws DataAccessException;
		// 조퇴
		public List<IcuVO> selectStd_Attd_Early(String std_id) throws DataAccessException;
		// 지각
		public List<IcuVO> selectStd_Attd_Late(String std_id) throws DataAccessException;
		//공지사항 출력
		public List<IcuVO> noticeAll_Std() throws DataAccessException;
		//공지사항 세부 출력
		public List<IcuVO> noticeView_Std(String notice_id) throws DataAccessException;
		// 커뮤니티 출력
		public List<IcuVO> communityAll_Std() throws DataAccessException;
						
		// 커뮤니티 세부 출력
		public List<IcuVO> communityView_Std(int community_id) throws DataAccessException;

		// 커뮤니티 등록
		public int communityInsert(IcuVO icuVO) throws DataAccessException;

		// 커뮤니티 수정
		public int communityMod(IcuVO icuVO) throws DataAccessException;
						
		// 커뮤니티 삭제
		public int communityDel(IcuVO icuVO) throws DataAccessException;
}
