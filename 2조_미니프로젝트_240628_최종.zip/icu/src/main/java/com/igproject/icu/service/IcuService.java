package com.igproject.icu.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.igproject.icu.vo.IcuVO;

public interface IcuService {
	// 관리자 로그인
    public IcuVO proLogin(IcuVO icuVO) throws Exception;

    // 학생 정보 확인
    public List studentInfo(String pro_id) throws Exception;
    
    // 학생 전체 정보 확인
    public List studentInfoAll(String std_id) throws Exception;
    
    // 본인 과목 수강하는 학생 정보
    public List proStdInfo(String pro_id) throws Exception;
    
    // 교수별 담당 과목 출력
    public List proSubject(String pro_id) throws Exception;
    
    // 과목별 수강 학생
    public List proSubStd(String sub_id) throws Exception;

    // 학생 정보 수정(관리자용)
    public int proStudentMod(IcuVO icuVO) throws Exception;

    // 학생 정보 삭제
    public int proStudentDel(String std_id) throws Exception;

    // 과목별 학생 목록 출력
    public List proStudentBySub(String sub_id) throws Exception;

    // 출결 등록
    public int proInsertAttd(IcuVO icuVO) throws Exception;

    // 출결 수정
    public int proModAttd(IcuVO icuVO) throws Exception;
    
    // 출결 조회
    public List proAttdInfo(String sub_id) throws Exception;

    // 점수 및 평균 조회
    public List proScoreByStudent(String sub_id) throws Exception;
    
    // 점수 업데이트
    public int proScoreInsert(IcuVO icuVO) throws Exception;
    
    // 교수쪽 공지사항 목록 출력
    public List noticeAll_Pro() throws Exception;

   // 공지사항 출력
   public List noticeView_Pro(String notice_id) throws Exception;

    // 공지사항 등록
    public int noticeInsert(IcuVO icuVO) throws Exception;
    
    // 공지사항 수정
    public int noticeMod(IcuVO icuVO) throws Exception;

    // 공지사항 삭제
    public int noticeDel(String notice_id) throws Exception;
    
    // 커뮤니티 출력
    public List communityAll_Pro() throws Exception;
    		
    // 커뮤니티 세부 출력
    public List communityView_Pro(int community_id) throws Exception;
    // 커뮤니티 삭제
    public int communityDel_Pro(int community_id) throws Exception;
    
    // ----------------------------------------------------------------
    
    //학생 로그인
  	public IcuVO login_std(IcuVO icuVO) throws Exception;
  
  	// 학생 메인페이지 정보
  	public List std_info(String std_id) throws Exception;
  	
  	// 학생 개인정보 확인
  	public List std_detail(String std_id) throws Exception;
  	
  	// 학생 개인정보 수정
  	public int std_mod(IcuVO icuVO) throws Exception;
  	
  	// 학기 성적 조회
  	public List sco_sem(IcuVO icuVO) throws Exception;
  	
  	// 전체 학기 성적 조회
  	public List sco_all(String std_id) throws Exception;
  	
  	// 이수 학점 가져오기
  	public List std_credit(String std_id) throws Exception;
  	
  	// 수강 과목 조회
  	public List std_lec(String std_id) throws Exception;
  	
  	// 출결 현황 조회
  	
  	// 출석
  	public List std_attd_t(String std_id) throws Exception;
  	
  	// 결석
  	public List std_attd_f(String std_id) throws Exception;
  	
  	// 조퇴
  	public List std_attd_early(String std_id) throws Exception;
  	
  	// 지각
  	public List std_attd_late(String std_id) throws Exception;
  	
 // 공지사항 목록 출력
  	public List noticeAll_Std() throws Exception;

  	// 공지사항 세부 출력
  	public List noticeView_Std(String notice_id) throws Exception;
  	
    // 커뮤니티 출력
    public List communityAll_Std() throws Exception;
    		
    // 커뮤니티 세부 출력
    public List communityView_Std(int community_id) throws Exception;

    // 커뮤니티 등록
    public int communityInsert(IcuVO icuVO) throws Exception;

    // 커뮤니티 수정
    public int communityMod(IcuVO icuVO) throws Exception;
    		
    // 커뮤니티 삭제
    public int communityDel(IcuVO icuVO) throws Exception;
  
}
