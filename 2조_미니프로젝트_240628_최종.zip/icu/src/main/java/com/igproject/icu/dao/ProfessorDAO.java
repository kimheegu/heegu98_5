package com.igproject.icu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.igproject.icu.vo.IcuVO;

@Mapper
@Repository("professorDAO")
public interface ProfessorDAO {
	
	// 관리자 로그인
    public IcuVO proLogin(IcuVO icuVO) throws DataAccessException;

    // 학생 정보 확인
    public List<IcuVO> studentInfo(String pro_id) throws DataAccessException;
    
    // 본인 과목 수강하는 학생 정보
    public List<IcuVO> proStdInfo(String pro_id) throws DataAccessException;
    
    // 학생 전체 정보 확인
    public List<IcuVO> studentInfoAll(String std_id) throws DataAccessException;

    // 학생 정보 수정(관리자용)
    public int proStudentMod(IcuVO icuVO) throws DataAccessException;

    // 학생 정보 삭제
    public int proStudentDel(String std_id) throws DataAccessException;

    // 과목별 학생 목록 출력 사용 안함
    public List<IcuVO> proStudentBySub(String sub_id) throws DataAccessException;
    
    // 교수별 담당 과목 출력
    public List<IcuVO> proSubject(String pro_id) throws DataAccessException;
    
    // 과목별 수강 학생
    public List<IcuVO> proSubStd(String sub_id) throws DataAccessException;

    // 출결 등록
    public int proInsertAttd(IcuVO icuVO) throws DataAccessException;

    // 출결 수정
    public int proModAttd(IcuVO icuVO) throws DataAccessException;

    // 출결 조회
    public List<IcuVO> proAttdInfo(String sub_id) throws DataAccessException;
    
    // 점수 조회
    public List<IcuVO> proScoreByStudent(String sub_id) throws DataAccessException;
    
    // 점수 업데이트
    public int proScoreInsert(IcuVO icuVO) throws DataAccessException;
    
    //공지사항 출력
    public List<IcuVO> noticeAll_Pro() throws DataAccessException;

    //공지사항 세부 출력
    public List<IcuVO> noticeView_Pro(String notice_id) throws DataAccessException;

     // 공지사항 등록
     public int noticeInsert(IcuVO icuVO) throws DataAccessException;

     // 공지사항 수정
     public int noticeMod(IcuVO icuVO) throws DataAccessException;    
     
     // 공지사항 삭제
     public int noticeDel(String notice_id) throws DataAccessException;
	
  // 커뮤니티 출력
     public List<IcuVO> communityAll_Pro() throws DataAccessException;
     					
     // 커뮤니티 세부 출력
     public List<IcuVO> communityView_Pro(int community_id) throws DataAccessException;

     // 커뮤니티 삭제
     public int communityDel_Pro(int community_id) throws DataAccessException;
}
