package com.igproject.icu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.igproject.icu.dao.ProfessorDAO;
import com.igproject.icu.dao.StudentDAO;
import com.igproject.icu.vo.IcuVO;

@Service("icuService")
@Transactional(propagation = Propagation.REQUIRED)
public class IcuServiceImpl implements IcuService {

	@Autowired
	private ProfessorDAO professorDAO;

	@Autowired
	private StudentDAO studentDAO;

	@Override
	public IcuVO proLogin(IcuVO icuVO) throws Exception {
		return professorDAO.proLogin(icuVO);
	}

	@Override
	public List studentInfo(String pro_id) throws Exception {
		List professor = null;
		professor = professorDAO.studentInfo(pro_id);
		return professor;	
	}
	
	@Override
	public List studentInfoAll(String std_id) throws Exception {
		List professor = null;
		professor = professorDAO.studentInfoAll(std_id);
		return professor;	
	}

	@Override
	public List proSubject(String pro_id) throws Exception {
		List professor = null;
		professor = professorDAO.proSubject(pro_id);
		return professor;
	}

	@Override
	public List proSubStd(String sub_id) throws Exception {
		List professor = null;
		professor = professorDAO.proSubStd(sub_id);
		return professor;
	}

	@Override
	public List proStdInfo(String pro_id) throws Exception {
		List professor = null;
		professor = professorDAO.proStdInfo(pro_id);
		return professor;	
	}

	@Override
	public int proStudentMod(IcuVO icuVO) throws Exception {
		return professorDAO.proStudentMod(icuVO);
	}

	@Override
	public int proStudentDel(String std_id) throws Exception {
		return professorDAO.proStudentDel(std_id);
	}

	@Override
	public List proStudentBySub(String sub_id) throws Exception {
		List professor = null;
		professor = professorDAO.studentInfo(sub_id);
		return professor;
	}

	@Override
	public int proInsertAttd(IcuVO icuVO) throws Exception {
		return professorDAO.proInsertAttd(icuVO);
	}

	@Override
	public int proModAttd(IcuVO icuVO) throws Exception {
		return professorDAO.proModAttd(icuVO);
	}
	

	@Override
	public List proAttdInfo(String sub_id) throws Exception {
		return professorDAO.proAttdInfo(sub_id);
	}

	// 점수 조회
	@Override
	public List proScoreByStudent(String sub_id) throws Exception {
		return professorDAO.proScoreByStudent(sub_id);
	}
	
	// 점수 업데이트
	public int proScoreInsert(IcuVO icuVO) throws Exception{
		return professorDAO.proScoreInsert(icuVO);
	}
	
	// 교수쪽 공지사항 출력
	@Override
	public List noticeAll_Pro() throws Exception {
		List noticeList = null;
		noticeList = professorDAO.noticeAll_Pro();
		return noticeList;
	}

	// 공지사항 세부 출력
	@Override
	public List noticeView_Pro(String notice_id) throws Exception {
		List noticeList = null;
		noticeList = professorDAO.noticeView_Pro(notice_id);
		return noticeList;
	}

	// 공지사항 등록
	@Override
	public int noticeInsert(IcuVO icuVO) throws Exception {
		return professorDAO.noticeInsert(icuVO);
	}
	
	// 공지사항 수정
	@Override
	public int noticeMod(IcuVO icuVO) throws Exception {
		return professorDAO.noticeMod(icuVO);
	}
	
	// 공지사항 삭제
	@Override
	public int noticeDel(String notice_id) throws Exception {
		return professorDAO.noticeDel(notice_id);
	}
	
	// 커뮤니티 출력
	@Override
	public List communityAll_Pro() throws Exception {
		List communityList = null;
		communityList = professorDAO.communityAll_Pro();
		return communityList;
	}

	// 커뮤니티 세부 출력
	@Override
	public List communityView_Pro(int community_id) throws Exception {
		List communityList = null;
		communityList = professorDAO.communityView_Pro(community_id);
		return communityList;
	}

	// 커뮤니티 글 삭제
	@Override
	public int communityDel_Pro(int community_id) throws Exception {
		return professorDAO.communityDel_Pro(community_id);
	}

	
	// --------------------------------------------------------------

	// 학생 로그인
	@Override
	public IcuVO login_std(IcuVO icuVO) throws Exception {
		return studentDAO.loginByStd(icuVO);
	}

	// 학생 메인페이지 정보
	@Override
	public List std_info(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Info(std_id);
		return stdList;
	}

	// 학생 개인정보 확인
	@Override
	public List std_detail(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Detail(std_id);
		return stdList;
	}

	// 학생 개인정보 수정
	@Override
	public int std_mod(IcuVO icuVO) throws Exception {
		return studentDAO.updateStd_Info(icuVO);
	}

	// 학기 성적 조회
	@Override
	public List sco_sem(IcuVO icuVO) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Sem(icuVO);
		return stdList;
	}

	// 전체 학기 성적 조회
	@Override
	public List sco_all(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_All(std_id);
		return stdList;
	}

	// 이수 학점 가져오기
	@Override
	public List std_credit(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Credit(std_id);
		return stdList;
	}

	// 수강 과목 조회
	@Override
	public List std_lec(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Lec(std_id);
		return stdList;
	}

	// 출결 현황 조회
	// 출석
	@Override
	public List std_attd_t(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Attd_T(std_id);
		return stdList;
	}

	// 결석
	@Override
	public List std_attd_f(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Attd_F(std_id);
		return stdList;
	}

	// 조퇴
	@Override
	public List std_attd_early(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Attd_Early(std_id);
		return stdList;
	}

	// 지각
	@Override
	public List std_attd_late(String std_id) throws Exception {
		List stdList = null;
		stdList = studentDAO.selectStd_Attd_Late(std_id);
		return stdList;
	}
	
	// 공지사항 출력
	@Override
		public List noticeAll_Std() throws Exception {
			List noticeList = null;
			noticeList = studentDAO.noticeAll_Std();
			return noticeList;
		}

	// 공지사항 세부 출력
	@Override
	public List noticeView_Std(String notice_id) throws Exception {
		List noticeList = null;
		noticeList = studentDAO.noticeView_Std(notice_id);
		return noticeList;
	}	
	
	// 커뮤니티 출력
	@Override
	public List communityAll_Std() throws Exception {
		List communityList = null;
		communityList = studentDAO.communityAll_Std();
		return communityList;
	}

	// 커뮤니티 세부 출력
	@Override
	public List communityView_Std(int community_id) throws Exception {
		List communityList = null;
		communityList = studentDAO.communityView_Std(community_id);
		return communityList;
	}

	// 커뮤니티 등록
	@Override
	public int communityInsert(IcuVO icuVO) throws Exception {
		return studentDAO.communityInsert(icuVO);
	}

	// 커뮤니티 수정
	@Override
	public int communityMod(IcuVO icuVO) throws Exception {
		return studentDAO.communityMod(icuVO);
	}

	// 커뮤니티 삭제
	@Override
	public int communityDel(IcuVO icuVO) throws Exception {
		return studentDAO.communityDel(icuVO);
	}

}
