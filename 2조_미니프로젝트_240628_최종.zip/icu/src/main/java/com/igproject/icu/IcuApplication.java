package com.igproject.icu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcuApplication {

	public static void main(String[] args) {
		SpringApplication.run(IcuApplication.class, args);
	}

}
