package com.igproject.icu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.igproject.icu.service.IcuService;
import com.igproject.icu.vo.IcuVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller("icuController")
public class IcuControllerImpl implements IcuController {

	@Autowired
	private IcuService icuService;

	@Autowired
	private IcuVO icuVO;


	// 관리자 로그인
		@Override
		@PostMapping("/professor/proLogin.do")
		public ModelAndView proLogin(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
			ModelAndView mav = new ModelAndView();
			icuVO = icuService.proLogin(icuVO);
			if (icuVO != null) {
				HttpSession session = request.getSession();
				session.setAttribute("professor", icuVO);
				session.setAttribute("pro_id", icuVO.getPro_id()); 
				session.setAttribute("isLogOn", true);

				String action = (String) session.getAttribute("action");
				session.removeAttribute("action");

				if (action != null) {
					mav.setViewName("redirect:" + action);
				} else {
					mav.setViewName("redirect:/professor/studentInfo.do");
					mav.addObject("pro_id",icuVO.getPro_id());
				}
			} else {
				rAttr.addAttribute("result", "loginFailed");
				mav.setViewName("redirect:/main/loginForm.do");
			}
			return mav;
		}

		// 로그아웃
		@Override
		@GetMapping("/main/logout.do")
		public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
			session.removeAttribute("icuVO");
			session.removeAttribute("sub_id");
			session.removeAttribute("pro_id");
			session.removeAttribute("std_id");
			session.removeAttribute("sub_name");
			session.removeAttribute("student");
			session.removeAttribute("professor");
			session.removeAttribute("community_id");
			session.setAttribute("isLogOn", false);

			ModelAndView mav = new ModelAndView();
			mav.setViewName("redirect:/main/loginForm.do");
			return mav;
		}

		// 학생 정보 확인
		@Override
		@GetMapping("/professor/studentInfo.do")
		public ModelAndView studentInfo(@RequestParam("pro_id") String pro_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
		    String proId = (String) session.getAttribute("pro_id");
			String viewName = (String) request.getAttribute("viewName");

			// String pro = (String) session.getAttribute("pro_id");
			List professor = icuService.studentInfo(pro_id);
			ModelAndView mav = new ModelAndView("/professor/proMain");
			mav.addObject("professor", professor);
			return mav;
		}
		
		// 학생 전체 정보 확인
		@Override
		@GetMapping("/professor/studentInfoAll.do")
		public ModelAndView studentInfoAll(@RequestParam("std_id") String std_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
			String viewName = (String) request.getAttribute("viewName");

			// String pro = (String) session.getAttribute("pro_id");
			List professor = icuService.studentInfoAll(std_id);
			ModelAndView mav = new ModelAndView("/professor/modForm");
			
			mav.addObject("professor", professor);
			return mav;
		}

		
		// 본인 과목 수강하는 학생 정보
		@Override
		@GetMapping("/professor/proStdInfo.do")
		public ModelAndView proStdInfo(@RequestParam("pro_id") String pro_id, HttpServletRequest request, HttpServletResponse response)
				throws Exception {
			HttpSession session = request.getSession();
			IcuVO pro = (IcuVO) session.getAttribute("professor");
			pro_id = pro.getPro_id();
			String viewName = (String) request.getAttribute("viewName");
			
			List professor = icuService.proStdInfo(pro_id);
			ModelAndView mav = new ModelAndView("redirect:/professor/proStudentBySub.do");
			mav.addObject("professor", professor);
			mav.addObject("pro_id",pro_id);
			return mav;
		}

		// 학생 정보 수정
		@Override
		@PostMapping("/professor/proStudentMod.do")
		public ModelAndView proStudentMod(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
			IcuVO pro = (IcuVO) session.getAttribute("professor");
			String pro_id = pro.getPro_id();
			request.setCharacterEncoding("utf-8");
			int result = 0;
			result = icuService.proStudentMod(icuVO);
			ModelAndView mav = new ModelAndView("redirect:/professor/studentInfo.do");
			mav.addObject("pro_id",pro_id);
			return mav;
		}

		// 학생 정보 삭제
		@Override
		@GetMapping("/professor/proStudentDel.do")
		public ModelAndView proStudentDel(@RequestParam("std_id") String std_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
			IcuVO pro = (IcuVO) session.getAttribute("professor");
			String pro_id = pro.getPro_id();
			request.setCharacterEncoding("utf-8");
			icuService.proStudentDel(std_id);
			ModelAndView mav = new ModelAndView("redirect:/professor/studentInfo.do");
			mav.addObject("pro_id",pro_id);
			return mav;
		}

		// 과목별 학생 목록
		@Override
		@GetMapping("/professor/proStudentBySub.do")
		public ModelAndView proStudentBySub(@RequestParam("sub_id") String sub_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			List professor = icuService.proStudentBySub(sub_id);
			ModelAndView mav = new ModelAndView("/professor/scoreInfo");
			mav.addObject("professor", professor);
			return mav;
		}
		
		// 교수별 담당 과목
		@Override
		@GetMapping("/professor/proSubject.do")
		public ModelAndView proSubject(@RequestParam("pro_id") String pro_id, HttpServletRequest request, HttpServletResponse response)
				throws Exception {
 			HttpSession session = request.getSession();
 			String proId = (String) session.getAttribute("pro_id");
//			IcuVO pro = (IcuVO) session.getAttribute("professor");
//			String proId = pro.getPro_id();
//			System.out.println(proId);
			List professor = icuService.proSubject(pro_id);
			session.setAttribute("professor", professor);
			ModelAndView mav = new ModelAndView("/professor/proSubject");
			mav.addObject("professor", professor);
//			mav.addObject("pro_id",proId);
			return mav;			
		}
		
		// 과목별 수강 학생
		@Override 
		@GetMapping("/professor/proSubStd.do")
		public ModelAndView proSubStd(@RequestParam("sub_id") String sub_id, HttpServletRequest request, HttpServletResponse response)
				throws Exception {
			HttpSession session = request.getSession();
			session.setAttribute("sub_id", sub_id);
			List professor = icuService.proSubStd(sub_id);
			session.setAttribute("sub_name", icuVO.getSub_name());
			ModelAndView mav = new ModelAndView("/professor/proSubStd");
			mav.addObject("professor", professor);
			mav.addObject("sub_id",sub_id);
			mav.addObject("sub_name",icuVO.getSub_name());
			return mav;
		}
		
		
		// 과목별 출결 조회
		@Override
		@GetMapping("/professor/proAttdInfo.do")
		public ModelAndView proAttdInfo(@RequestParam("sub_id") String sub_id, HttpServletRequest request, HttpServletResponse response)
				throws Exception {
			HttpSession session = request.getSession();
 			session.setAttribute("sub_id",sub_id);
			List professor = icuService.proAttdInfo(sub_id);
			ModelAndView mav = new ModelAndView("/professor/proAttdInfo");
			mav.addObject("professor", professor);
			return mav;
		}


		// 출결 등록
		@Override
		@PostMapping("/professor/proInsertAttd.do")
		public ModelAndView proInsertAttd(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			request.setCharacterEncoding("utf-8");
			int result = 0;
			result = icuService.proInsertAttd(icuVO);
			ModelAndView mav = new ModelAndView("redirect:/professor/studentInfo.do");
			return mav;
		}

		// 출결 수정
		@Override
		@PostMapping("/professor/proModAttd.do")
		public ModelAndView proModAttd(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			request.setCharacterEncoding("utf-8");
			HttpSession session = request.getSession();
			String subId = (String) session.getAttribute("sub_id");
			int result = 0;
			result = icuService.proModAttd(icuVO);
			ModelAndView mav = new ModelAndView("redirect:/professor/proAttdInfo.do");
			mav.addObject("sub_id",subId);
			return mav;
		}

		// 과목별 성적 조회
		@Override
		@GetMapping("/professor/proScoreByStudent.do")
		public ModelAndView proScoreByStudent(@RequestParam("sub_id") String sub_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
			String subId = (String) session.getAttribute("sub_id");
			List professor = icuService.proScoreByStudent(sub_id);
			session.setAttribute("professor", professor);
			ModelAndView mav = new ModelAndView("/professor/proScoreByStudent");
			mav.addObject("professor", professor);
			return mav;
		}
		
		// 성적 업데이트 시 학생 정보 전달
		@GetMapping("/professor/proScoreInsert1.do")
		public ModelAndView proScoreInsert1(@RequestParam("sub_id") String sub_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
			List professor = icuService.proScoreByStudent(sub_id);
			session.setAttribute("professor",professor);
			ModelAndView mav = new ModelAndView("redirect:/professor/proScoreInsertForm.do");
			mav.addObject("professor", professor);
			return mav;
		}
		
		// 성적 업데이트
		@Override
		@PostMapping("/professor/proScoreInsert2.do")
		public ModelAndView proScoreInsert(
		    @RequestParam("std_id") List<String> stdIds,
		    @RequestParam("score_mid") List<Integer> scoreMids,
		    @RequestParam("score_fin") List<Integer> scoreFins,
		    @RequestParam("score_att") List<Integer> scoreAtts,
		    @RequestParam("score_grd") List<Double> scoreGrds,
		    HttpServletRequest request, HttpServletResponse response) throws Exception {

		    request.setCharacterEncoding("utf-8");
		    HttpSession session = request.getSession();
		    String subId = (String) session.getAttribute("sub_id");
		    int result = 0;

		    for (int i = 0; i < stdIds.size(); i++) {
		        IcuVO icuVO = new IcuVO();
		        icuVO.setStd_id(stdIds.get(i)); // setStd_id
		        icuVO.setScore_mid(scoreMids.get(i)); // setScore_mid
		        icuVO.setScore_fin(scoreFins.get(i)); // setScore_fin
		        icuVO.setScore_att(scoreAtts.get(i)); // setScore_att
		        icuVO.setScore_grd(scoreGrds.get(i)); // setScore_grd (double 타입)
		        icuVO.setSub_id(subId); // setSub_id

		        result += icuService.proScoreInsert(icuVO);
		    }

		    ModelAndView mav = new ModelAndView("redirect:/professor/proScoreByStudent.do");
		    mav.addObject("sub_id", subId);
		    return mav;
		}


		@GetMapping("/*/*Form.do")
		private ModelAndView form(@RequestParam(value = "result", required = false) String result,
				@RequestParam(value = "action", required = false) String action, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			String viewName = (String) request.getAttribute("viewName");
			HttpSession session = request.getSession();
			session.setAttribute("action", action);

			ModelAndView mav = new ModelAndView();
			mav.addObject("result", result);
			mav.setViewName(viewName);
			return mav;
		}
		
		// 교수쪽 공지사항 목록
		@Override
		@GetMapping("/professor/noticeAll_pro.do")
		public ModelAndView noticeAll_Pro(HttpServletRequest request, HttpServletResponse response) throws Exception{
				String viewName = (String)request.getAttribute("viewName");
				List noticeList = icuService.noticeAll_Pro();
				ModelAndView mav = new ModelAndView("/professor/noticeAll_pro");
				mav.addObject("noticeList", noticeList);
				return mav;
			}

		// 교수쪽 공지사항 세부 출력
		@Override
		@GetMapping("/professor/noticeView_pro.do")
		public ModelAndView noticeView_Pro(@RequestParam("notice_id") String notice_id, HttpServletRequest request, HttpServletResponse response) throws Exception{
				HttpSession session = request.getSession();
				session.setAttribute("notice_id",notice_id);
				
				String viewName = (String)request.getAttribute("viewName");
				List noticeList = icuService.noticeView_Std(notice_id);
				ModelAndView mav = new ModelAndView("/professor/noticeView_pro");
				mav.addObject("noticeList", noticeList);
				mav.addObject("notice_id", notice_id);
				return mav;
		}	

		// 공지사항 등록
		@Override
		@PostMapping("/professor/noticeInsert.do")
		public ModelAndView noticeInsert(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
				request.setCharacterEncoding("utf-8");
				HttpSession session = request.getSession();
				String proId = (String) session.getAttribute("pro_id");
				
				int result = 0;
				result =icuService.noticeInsert(icuVO);
				ModelAndView mav = new ModelAndView("redirect:/professor/noticeAll_pro.do");
				mav.addObject("pro_id", proId);
				return mav;
		}
			
		// 공지사항 수정
		@Override
		@PostMapping("/professor/noticeMod.do")
		public ModelAndView noticeMod(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
				request.setCharacterEncoding("utf-8");
				HttpSession session = request.getSession();
				String proId = (String) session.getAttribute("pro_id");
				int result = 0;
				result =icuService.noticeMod(icuVO);
				
				ModelAndView mav = new ModelAndView("redirect:/professor/noticeAll_pro.do");
				mav.addObject("pro_id", proId);
				return mav;
		}

		// 공지사항 삭제
		@Override
		@GetMapping("/professor/noticeDel.do")
		public ModelAndView noticeDel(@RequestParam("notice_id") String notice_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
				HttpSession session = request.getSession();
				String proId = (String) session.getAttribute("pro_id");
				int result = 0;
				result = icuService.noticeDel(notice_id);
				ModelAndView mav = new ModelAndView("redirect:/professor/noticeAll_pro.do");
				mav.addObject("pro_id", proId);
				return mav;
		}
		
		// 교수쪽 커뮤니티 목록 출력
				@Override
				@GetMapping("/professor/communityAllPro.do")
				public ModelAndView communityAll_Pro(HttpServletRequest request, HttpServletResponse response) throws Exception{
					HttpSession session = request.getSession();
					String proId = (String) session.getAttribute("pro_id");
					String viewName = (String)request.getAttribute("viewName");
					
					List communityList = icuService.communityAll_Pro();
					
					ModelAndView mav = new ModelAndView("/professor/communityAllPro");
					mav.addObject("communityList", communityList);
						return mav;
				}

				// 교수쪽 커뮤니티 세부 출력
				@Override
				@GetMapping("/professor/communityViewPro.do")
				public ModelAndView communityView_Pro(@RequestParam("community_id") int community_id, HttpServletRequest request, HttpServletResponse response) throws Exception{
					String viewName = (String)request.getAttribute("viewName");
					HttpSession session = request.getSession();
					String proId = (String) session.getAttribute("pro_id");
			
					List communityList = icuService.communityView_Pro(community_id);
				
					ModelAndView mav = new ModelAndView("/professor/communityViewPro");
					mav.addObject("pro_id", proId);
					mav.addObject("communityList", communityList);
					return mav;
				}
				

				// 커뮤니티 게시글 삭제
				@Override
				@GetMapping("/professor/communityDelPro.do")
				public ModelAndView communityDel_Pro(@RequestParam("community_id") int community_id, HttpServletRequest request,
						HttpServletResponse response) throws Exception {
						HttpSession session = request.getSession();
						String proId = (String) session.getAttribute("pro_id");
						
						int result = 0;
						
						result = icuService.communityDel_Pro(community_id);
						
						ModelAndView mav = new ModelAndView("redirect:/professor/communityAllPro.do");
						mav.addObject("pro_id", proId);
						return mav;
				}


	// -----------------------------------------------------------------------------------------------------

	// 학생 로그인
	@Override
	@PostMapping("/student/studentLogin.do")
	public ModelAndView login_std(@ModelAttribute("student") IcuVO icuVO, RedirectAttributes rAttr,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		icuVO = icuService.login_std(icuVO);

		if (icuVO != null) {
			HttpSession session = request.getSession();
			session.setAttribute("student", icuVO);
			session.setAttribute("std_id", icuVO.getStd_id());
			session.setAttribute("isLogOn", true);
//			String std_id = (String)icuVO.getStd_id();
//			session.setAttribute("std_id",std_id);

			String action = (String) session.getAttribute("action");
			session.removeAttribute("action");

			if (action != null) {
				mav.setViewName("redirect:" + action);
			} else {
				mav.setViewName("redirect:/student/studentMain.do");
				mav.addObject("std_id", icuVO.getStd_id());
				System.out.print(icuVO.getStd_id());
			}
		} else {
			rAttr.addAttribute("result", "loginFailed");
			mav.setViewName("redirect:/main/loginForm.do");
		}
		return mav;		
	}


	// 학생 메인페이지
	@Override
	@GetMapping("/student/studentMain.do")
	public ModelAndView std_info(@RequestParam("std_id") String std_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		List stdList = icuService.std_info(std_id);
		ModelAndView mav = new ModelAndView("/student/studentMain");

		mav.addObject("stdList", stdList);
		System.out.print(stdList);
		return mav;
	}
	
	// 학생 개인정보 확인
	@Override
	@GetMapping("/student/studentDetail.do")
	public ModelAndView std_detail(@RequestParam("std_id") String std_id, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		//HttpSession session = request.getSession();
		//IcuVO icuVO = (IcuVO)session.getAttribute("student");
		//String stdId = icuVO.getStd_id();
		List stdList = icuService.std_info(std_id);
		ModelAndView mav = new ModelAndView("/student/studentDetail");
		mav.addObject("stdList", stdList);
		return mav;
	}
	
	// 학생 개인정보 수정
	@Override
	@PostMapping("/student/studentMod.do")
	public ModelAndView std_mod(@ModelAttribute("student") IcuVO icuVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		int result = 0;
		
		 // 세션에 학생 정보 업데이트
	    HttpSession session = request.getSession();
	    session.setAttribute("student", icuVO);
	    
		result = icuService.std_mod(icuVO);
		ModelAndView mav = new ModelAndView("redirect:/student/studentDetail.do");
		mav.addObject("std_id", icuVO.getStd_id());
		return mav;
	}


	// 학기 성적 조회
	@Override
	@GetMapping("/student/studentScoreGrade.do") // 추후 수정
	public ModelAndView sco_sem(@ModelAttribute("student") IcuVO icuVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		List stdList = icuService.sco_sem(icuVO);
		ModelAndView mav = new ModelAndView("/student/studentScore");

		mav.addObject("stdList", stdList);
		return mav;
	}

	// 전체 학기 성적 조회
	@Override
	@GetMapping("/student/studentScore.do") // 추후 수정
	public ModelAndView sco_all(@RequestParam("std_id") String std_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		List stdList = icuService.sco_all(std_id);
		ModelAndView mav = new ModelAndView("/student/studentScore");

		mav.addObject("stdList", stdList);
		return mav;
	}

	// 이수 학점 가져오기
	@Override
	@GetMapping("eee.do") // 추후 수정
	public ModelAndView std_credit(@RequestParam("std_id") String std_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		List stdList = icuService.std_credit(std_id);
		ModelAndView mav = new ModelAndView(viewName);

		mav.addObject("stdList", stdList);
		return mav;
	}

	// 수강 과목 조회
	@Override
	@GetMapping("/student/studentSubject.do") // 추후 수정
	public ModelAndView std_lec(@RequestParam("std_id") String std_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		List stdList = icuService.std_lec(std_id);
		ModelAndView mav = new ModelAndView(viewName);

		mav.addObject("stdList", stdList);
		return mav;
	}

	// 출결 현황 조회
	@Override
	@GetMapping("/student/studentAttendance.do") // 추후 수정
	public ModelAndView std_attd(@RequestParam("std_id") String std_id, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");

		List stdList_t = icuService.std_attd_t(std_id); // 출석
		List stdList_f = icuService.std_attd_f(std_id); // 결석
		List stdList_e = icuService.std_attd_early(std_id); // 조퇴
		List stdList_l = icuService.std_attd_late(std_id); // 지각

		ModelAndView mav = new ModelAndView(viewName);

		mav.addObject("stdList_t", stdList_t);
		mav.addObject("stdList_f", stdList_f);
		mav.addObject("stdList_e", stdList_e);
		mav.addObject("stdList_l", stdList_l);

		return mav;
	}
	
	// 학생쪽 공지사항 목록 출력
	@Override
	@GetMapping("/student/noticeAll.do")
	public ModelAndView noticeAll_Std(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String viewName = (String)request.getAttribute("viewName");
		List noticeList = icuService.noticeAll_Std();
		ModelAndView mav = new ModelAndView("/student/noticeAll");
		mav.addObject("noticeList", noticeList);
		return mav;
	}
	
	@GetMapping("/student/noticeAll2.do")
	public ModelAndView noticeAll_Std2(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String viewName = (String)request.getAttribute("viewName");
		List noticeList = icuService.noticeAll_Std();
		ModelAndView mav = new ModelAndView("/student/noticeAll2");
		mav.addObject("noticeList", noticeList);
		return mav;
	}

	// 학생쪽 공지사항 세부 출력
	@Override
	@GetMapping("/student/noticeView.do")
	public ModelAndView noticeView_Std(@RequestParam("notice_id") String notice_id, HttpServletRequest request, HttpServletResponse response) throws Exception{
		String viewName = (String)request.getAttribute("viewName");
		List noticeList = icuService.noticeView_Std(notice_id);
		ModelAndView mav = new ModelAndView("/student/noticeView");
		mav.addObject("noticeList", noticeList);
		return mav;
	}
	
	// 학생쪽 커뮤니티 목록 출력
	@Override
	@GetMapping("/student/communityAll.do")
	public ModelAndView communityAll_Std(HttpServletRequest request, HttpServletResponse response) throws Exception{
		HttpSession session = request.getSession();
		String std_id = (String) session.getAttribute("std_id");
		String viewName = (String)request.getAttribute("viewName");
		List communityList = icuService.communityAll_Std();
		ModelAndView mav = new ModelAndView("/student/communityAll");
		mav.addObject("communityList", communityList);
			return mav;
	}

	@GetMapping("/student/communityAll2.do")
	public ModelAndView communityAll_Std2(HttpServletRequest request, HttpServletResponse response) throws Exception{
		HttpSession session = request.getSession();
		String std_id = (String) session.getAttribute("std_id");
		String viewName = (String)request.getAttribute("viewName");
		List communityList = icuService.communityAll_Std();
		ModelAndView mav = new ModelAndView("/student/communityAll2");
		mav.addObject("communityList", communityList);
		return mav;
	}
	
	// 학생쪽 커뮤니티 세부 출력
	@Override
	@GetMapping("/student/communityView.do")
	public ModelAndView communityView_Std(@RequestParam("community_id") int community_id, HttpServletRequest request, HttpServletResponse response) throws Exception{
		String viewName = (String)request.getAttribute("viewName");
		HttpSession session = request.getSession();
		String std_id = (String) session.getAttribute("std_id"); 
		session.setAttribute("community_id", community_id);
			
		List communityList = icuService.communityView_Std(community_id);
		ModelAndView mav = new ModelAndView("/student/communityView");
		mav.addObject("std_id", std_id);
		mav.addObject("communityList", communityList);
		return mav;
	}
		
	// 커뮤니티 등록
	@Override
	@PostMapping("/student/communityInsert.do")
	public ModelAndView communityInsert(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			request.setCharacterEncoding("utf-8");
			HttpSession session = request.getSession();
			String std_id = (String) session.getAttribute("std_id");
				
			int result = 0;
			result =icuService.communityInsert(icuVO);
			ModelAndView mav = new ModelAndView("redirect:/student/communityAll2.do");

			return mav;
	}
		
			
	// 커뮤니티 수정
	@Override
	@PostMapping("/student/communityMod.do")
	public ModelAndView communityMod(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			request.setCharacterEncoding("utf-8");
			HttpSession session = request.getSession();
			String std_id = (String) session.getAttribute("std_id");
			Integer community_id = (Integer) session.getAttribute("community_id"); 
				
			int result = 0;
			icuVO.setCommunity_id(community_id);
			icuVO.setStd_id(std_id);
			result =icuService.communityMod(icuVO);
			System.out.println(icuService.communityMod(icuVO));
				
			ModelAndView mav = new ModelAndView("redirect:/student/communityAll2.do");
			return mav;
	}

	// 커뮤니티 삭제
	@Override
	@GetMapping("/student/communityDel.do")
	public ModelAndView communityDel(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
			HttpSession session = request.getSession();
			String std_id = (String) session.getAttribute("std_id");
			Integer community_id = (Integer) session.getAttribute("community_id"); 
				
			int result = 0;
			icuVO.setCommunity_id(community_id);
			icuVO.setStd_id(std_id);
				
			result = icuService.communityDel(icuVO);
			System.out.println(result);
				
			ModelAndView mav = new ModelAndView("redirect:/student/communityAll2.do");
			return mav;
	}
	
}
