package com.igproject.icu.vo;

import java.sql.*;

import org.springframework.stereotype.Component;

@Component("icuVO")
public class IcuVO {
	// student
	private String std_id;
	private String std_pwd;
	private String std_name;
	private String std_grade;
	private String std_status;
	private String std_email;
	private String std_phone;
	private String std_address;
	
	// professor
	private String pro_id;
	private String pro_pwd;
	private String pro_name;
	
	// major
	private String major_id;
	private String major_name;
	
	// score	
	private int score_id;
	private int score_mid;
	private int score_fin;
	private int score_att;
	private double score_grd;
	
	// subject
	private String sub_id;
	private String sub_name;
	private String sub_course;
	private String sub_semester;
	private String sub_day;
	private Time sub_start_time;
	private Time sub_end_time;
	private int sub_credit;
	
	// lecture
	private int lec_id;	
	
	// attendance
	private int att_id;
	private Date att_date;
	private String att_status;
	
	// notice
	private int notice_id;
	private String notice_name; // 공지사항 제목
	private String notice_content; // 공지사항 내용
	private Date notice_date; // 공지사항 작성일 
	
	// community
	private int community_id;
	private String community_name; // 커뮤니티 제목
	private String community_content; // 커뮤니티 내용
	private Date community_date; // 커뮤니티 작성일 
	private String community_writer; // 글 작성자
	
	// getter, setter
	public String getStd_id() {
		return std_id;
	}
	public void setStd_id(String std_id) {
		this.std_id = std_id;
	}
	public String getStd_pwd() {
		return std_pwd;
	}
	public void setStd_pwd(String std_pwd) {
		this.std_pwd = std_pwd;
	}
	public String getStd_name() {
		return std_name;
	}
	public void setStd_name(String std_name) {
		this.std_name = std_name;
	}
	public String getStd_grade() {
		return std_grade;
	}
	public void setStd_grade(String std_grade) {
		this.std_grade = std_grade;
	}
	public String getStd_status() {
		return std_status;
	}
	public void setStd_status(String std_status) {
		this.std_status = std_status;
	}
	public String getStd_email() {
		return std_email;
	}
	public void setStd_email(String std_email) {
		this.std_email = std_email;
	}
	public String getStd_phone() {
		return std_phone;
	}
	public void setStd_phone(String std_phone) {
		this.std_phone = std_phone;
	}
	public String getStd_address() {
		return std_address;
	}
	public void setStd_address(String std_address) {
		this.std_address = std_address;
	}
	public String getPro_id() {
		return pro_id;
	}
	public void setPro_id(String pro_id) {
		this.pro_id = pro_id;
	}
	public String getPro_pwd() {
		return pro_pwd;
	}
	public void setPro_pwd(String pro_pwd) {
		this.pro_pwd = pro_pwd;
	}
	public String getMajor_id() {
		return major_id;
	}
	public void setMajor_id(String major_id) {
		this.major_id = major_id;
	}
	public String getMajor_name() {
		return major_name;
	}
	public void setMajor_name(String major_name) {
		this.major_name = major_name;
	}
	public int getScore_id() {
		return score_id;
	}
	public void setScore_id(int score_id) {
		this.score_id = score_id;
	}
	public int getScore_mid() {
		return score_mid;
	}
	public void setScore_mid(int score_mid) {
		this.score_mid = score_mid;
	}
	public int getScore_fin() {
		return score_fin;
	}
	public void setScore_fin(int score_fin) {
		this.score_fin = score_fin;
	}
	public int getScore_att() {
		return score_att;
	}
	public void setScore_att(int score_att) {
		this.score_att = score_att;
	}
	public double getScore_grd() {
		return score_grd;
	}
	public void setScore_grd(double score_grd) {
		this.score_grd = score_grd;
	}
	public String getSub_id() {
		return sub_id;
	}
	public void setSub_id(String sub_id) {
		this.sub_id = sub_id;
	}
	public String getSub_name() {
		return sub_name;
	}
	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}
	public String getSub_course() {
		return sub_course;
	}
	public void setSub_course(String sub_course) {
		this.sub_course = sub_course;
	}
	public String getSub_semester() {
		return sub_semester;
	}
	public void setSub_semester(String sub_semester) {
		this.sub_semester = sub_semester;
	}
	public String getSub_day() {
		return sub_day;
	}
	public void setSub_day(String sub_day) {
		this.sub_day = sub_day;
	}
	public Time getSub_start_time() {
		return sub_start_time;
	}
	public void setSub_start_time(Time sub_start_time) {
		this.sub_start_time = sub_start_time;
	}
	public Time getSub_end_time() {
		return sub_end_time;
	}
	public void setSub_end_time(Time sub_end_time) {
		this.sub_end_time = sub_end_time;
	}
	public int getSub_credit() {
		return sub_credit;
	}
	public void setSub_credit(int sub_credit) {
		this.sub_credit = sub_credit;
	}
	public int getLec_id() {
		return lec_id;
	}
	public void setLec_id(int lec_id) {
		this.lec_id = lec_id;
	}
	public int getAtt_id() {
		return att_id;
	}
	public void setAtt_id(int att_id) {
		this.att_id = att_id;
	}
	public Date getAtt_date() {
		return att_date;
	}
	public void setAtt_date(Date att_date) {
		this.att_date = att_date;
	}
	public String getAtt_status() {
		return att_status;
	}
	public void setAtt_status(String att_status) {
		this.att_status = att_status;
	}
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public int getNotice_id() {
		return notice_id;
	}
	public void setNotice_id(int notice_id) {
		this.notice_id = notice_id;
	}
	public String getNotice_name() {
		return notice_name;
	}
	public void setNotice_name(String notice_name) {
		this.notice_name = notice_name;
	}
	public String getNotice_content() {
		return notice_content;
	}
	public void setNotice_content(String notice_content) {
		this.notice_content = notice_content;
	}
	public Date getNotice_date() {
		return notice_date;
	}
	public void setNotice_date(Date notice_date) {
		this.notice_date = notice_date;
	}
	public int getCommunity_id() {
		return community_id;
	}
	public void setCommunity_id(int community_id) {
		this.community_id = community_id;
	}
	public String getCommunity_name() {
		return community_name;
	}
	public void setCommunity_name(String community_name) {
		this.community_name = community_name;
	}
	public String getCommunity_content() {
		return community_content;
	}
	public void setCommunity_content(String community_content) {
		this.community_content = community_content;
	}
	public Date getCommunity_date() {
		return community_date;
	}
	public void setCommunity_date(Date community_date) {
		this.community_date = community_date;
	}
	public String getCommunity_writer() {
		return community_writer;
	}
	public void setCommunity_writer(String community_writer) {
		this.community_writer = community_writer;
	}
	
	
}
