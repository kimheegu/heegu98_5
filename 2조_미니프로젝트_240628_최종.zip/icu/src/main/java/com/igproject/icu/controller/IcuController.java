package com.igproject.icu.controller;

import java.util.List;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.igproject.icu.vo.IcuVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface IcuController {
	// 관리자 로그인
		public ModelAndView proLogin(@ModelAttribute("icuVO") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response, RedirectAttributes rAttr) throws Exception;
		
		// 로그아웃
		public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;

		// 학생 정보 확인
		public ModelAndView studentInfo(@RequestParam("pro_id") String pro_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 학생 전체 정보 확인
		public ModelAndView studentInfoAll(@RequestParam("std_id") String std_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;

		// 본인 과목 수강하는 학생 정보
		public ModelAndView proStdInfo(@RequestParam("pro_id") String pro_id, HttpServletRequest request,
					HttpServletResponse response) throws Exception;
		
		// 학생 정보 수정(관리자용)
		public ModelAndView proStudentMod(@ModelAttribute("professor") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception;

		// 학생 정보 삭제
		public ModelAndView proStudentDel(@RequestParam("std_id") String std_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;

		// 과목별 학생 목록 출력
		public ModelAndView proStudentBySub(@ModelAttribute("sub_id") String sub_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;

		// 교수별 담당 과목
		public ModelAndView proSubject(@RequestParam("pro_id") String pro_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 과목별 수강 학생
		public ModelAndView proSubStd(@RequestParam("sub_id") String sub_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 출결 등록
		public ModelAndView proInsertAttd(@ModelAttribute("professor") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception;

		// 출결 수정
		public ModelAndView proModAttd(@ModelAttribute("professor") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 출결 조회
		public ModelAndView proAttdInfo(@RequestParam("sub_id") String sub_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;

		// 점수 및 평균 조회
		public ModelAndView proScoreByStudent(@RequestParam("sub_id") String sub_id, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 점수 업데이트
		public ModelAndView proScoreInsert(
				@RequestParam("std_id") List<String> stdIds,
			    @RequestParam("score_mid") List<Integer> scoreMids,
			    @RequestParam("score_fin") List<Integer> scoreFins,
			    @RequestParam("score_att") List<Integer> scoreAtts,
			    @RequestParam("score_grd") List<Double> scoreGrds, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 공지사항 출력
		public ModelAndView noticeAll_Pro(HttpServletRequest request, HttpServletResponse response) throws Exception;

		// 공지사항 세부 출력
		public ModelAndView noticeView_Pro(@RequestParam("notice_id") String notice_id,
				HttpServletRequest request, HttpServletResponse response) throws Exception;

		// 공지사항 등록
		public ModelAndView noticeInsert(@ModelAttribute("notice") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 공지사항 수정
		public ModelAndView noticeMod(@ModelAttribute("notice") IcuVO icuVO, HttpServletRequest request,
				HttpServletResponse response) throws Exception;
		
		// 공지사항 삭제
		public ModelAndView noticeDel(@RequestParam("notice_id") String notice_id, HttpServletRequest request, HttpServletResponse response) throws Exception;
		
		
		// 커뮤니티 출력
		public ModelAndView communityAll_Pro(HttpServletRequest request, HttpServletResponse response) throws Exception;

		// 커뮤니티 세부 출력
		public ModelAndView communityView_Pro(@RequestParam("community_id") int community_id,
				HttpServletRequest request, HttpServletResponse response) throws Exception;

		// 커뮤니티 삭제
		public ModelAndView communityDel_Pro(@RequestParam("community_id") int community_id, 
				HttpServletRequest request, HttpServletResponse response) throws Exception;
	// ------------------------------------------------------------------------------------------------------
	
	
	// 학생 로그인
	public ModelAndView login_std(@ModelAttribute("student") IcuVO icuVO, RedirectAttributes redirectAttributes, 
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 학생 마이페이지 정보
	public ModelAndView std_info(@RequestParam("std_id") String std_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 학생 개인정보 확인
	public ModelAndView std_detail(@RequestParam("std_id") String std_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 학생 개인정보 수정
	public ModelAndView std_mod(@ModelAttribute("student") IcuVO icuVO,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 학기 성적 조회
	public ModelAndView sco_sem(@ModelAttribute("student") IcuVO icuVO,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 전체 학기 성적 조회
	public ModelAndView sco_all(@RequestParam("std_id") String std_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 이수 학점 가져오기
	public ModelAndView std_credit(@RequestParam("std_id") String std_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 수강 과목 조회
	public ModelAndView std_lec(@RequestParam("std_id") String std_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	//출결 현황 조회
	public ModelAndView std_attd(@RequestParam("std_id") String std_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 공지사항 출력
	public ModelAndView noticeAll_Std(HttpServletRequest request, HttpServletResponse response) throws Exception;
		
	// 공지사항 세부 출력
	public ModelAndView noticeView_Std(@RequestParam("notice_id") String notice_id,
		HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 커뮤니티 출력
	public ModelAndView communityAll_Std(HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 커뮤니티 세부 출력
	public ModelAndView communityView_Std(@RequestParam("community_id") int community_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;

	// 커뮤니티 등록
	public ModelAndView communityInsert(@ModelAttribute("community") IcuVO icuVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception;
		
	// 커뮤니티 수정
	public ModelAndView communityMod(@ModelAttribute("community") IcuVO icuVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception;
		
	// 커뮤니티 삭제
	public ModelAndView communityDel(@ModelAttribute("community") IcuVO icuVO, HttpServletRequest request, HttpServletResponse response) throws Exception;

}
